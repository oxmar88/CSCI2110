// Omar Elsayed B00993452

I commented out line 103 in orderedList.java to prevent multiple unwanted messages
For the file paths before use please alter the paths accordingly on you machine to see the output and to be able to read and write to the files
The text files i attached are filled with a sample run I ran on my machine you should re run and check if line lengths change to tell if it worked.