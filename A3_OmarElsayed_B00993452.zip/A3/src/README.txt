Instructions to run my code:

open the demo file and change fields with desired country date or any method you want to call in my demo I provided
an example based on what was given in assignment

Assumptions:

To run my file I assumed we have a functional Linked List, List and node class as provided with Tasks

I also made the assumption not to count any draws thats why my most won team displayed France rather than argentina who won

Another final assumption would be you need to alter the path to the file as I had to use my specific path to get the code up and running


